require 'tzinfo/timezone_definition'

module TZInfo
  module Definitions
    module NZ
      include TimezoneDefinition
      
      linked_timezone 'NZ', 'Pacific/Auckland'
    end
  end
end
