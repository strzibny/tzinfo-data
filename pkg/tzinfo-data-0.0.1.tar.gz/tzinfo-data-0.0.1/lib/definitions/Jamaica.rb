require 'tzinfo/timezone_definition'

module TZInfo
  module Definitions
    module Jamaica
      include TimezoneDefinition
      
      linked_timezone 'Jamaica', 'America/Jamaica'
    end
  end
end
